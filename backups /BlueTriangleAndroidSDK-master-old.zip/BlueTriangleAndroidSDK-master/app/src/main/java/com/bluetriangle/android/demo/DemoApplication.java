package com.bluetriangle.android.demo;

import android.app.Application;
import com.bluetriangle.analytics.Tracker;

public class DemoApplication extends Application {

    private Tracker tracker;

    @Override
    public void onCreate() {
        super.onCreate();
        // d.btttag.com => 107.22.227.162
        tracker = Tracker.init(getApplicationContext(), null, "http://107.22.227.162/btt.gif");
    }
}


